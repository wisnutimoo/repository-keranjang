<!-- /.navbar -->
<div class="content-wrapper">
  <div class="container-fluid">
    <div class="alert alert-success">
      <p align="text-center align-middle">Selamat pesanan anda telah berhasil diproses</p>
      <br>

    </div>

  </div>
</div>